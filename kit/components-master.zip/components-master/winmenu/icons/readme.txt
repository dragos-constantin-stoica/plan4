Icons by fediaFedia
http://fediafedia.deviantart.com/art/Reconstructed-Windows-8-Start-Screen-Icons-290816160