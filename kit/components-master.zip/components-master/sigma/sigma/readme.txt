An open-source lightweight JavaScript graph drawing library

http://sigmajs.org/
https://github.com/jacomyal/sigma.js
